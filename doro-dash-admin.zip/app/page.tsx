"use client"

import { useState, useEffect } from "react"
import {
  Bell,
  Package,
  Clock,
  CheckCircle,
  Truck,
  Search,
  RefreshCw,
  Phone,
  MapPin,
  User,
  MessageSquare,
  DollarSign,
  TrendingUp,
  Calendar,
  Eye,
  Download,
  Settings,
  X,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"

type OrderStatus = "pending" | "preparing" | "out-for-delivery" | "delivered" | "cancelled"

interface OrderItem {
  id: string
  name: string
  quantity: number
  price: number
  specialInstructions?: string
  category: string
}

interface Order {
  id: string
  customerName: string
  email: string
  phone: string
  address: string
  items: OrderItem[]
  total: number
  status: OrderStatus
  orderTime: Date
  estimatedDelivery?: Date
  specialInstructions?: string
  deliveryFee: number
  tax: number
  subtotal: number
}

// Enhanced sample database
const sampleDatabase: Order[] = [
  {
    id: "ORD-2024-001",
    customerName: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    phone: "+1 (555) 123-4567",
    address: "123 Main Street, Apt 4B, Downtown District, New York, NY 10001",
    items: [
      {
        id: "1",
        name: "Spicy Buffalo Wings (12pc)",
        quantity: 1,
        price: 18.99,
        category: "Wings",
        specialInstructions: "Extra spicy",
      },
      { id: "2", name: "Classic Chicken Sandwich", quantity: 2, price: 12.99, category: "Sandwiches" },
      { id: "3", name: "Seasoned Fries (Large)", quantity: 1, price: 6.99, category: "Sides" },
      { id: "4", name: "Coca-Cola (2L)", quantity: 1, price: 3.99, category: "Beverages" },
    ],
    subtotal: 55.95,
    tax: 4.48,
    deliveryFee: 3.99,
    total: 64.42,
    status: "pending",
    orderTime: new Date(Date.now() - 3 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() + 27 * 60 * 1000),
    specialInstructions: "Please ring doorbell twice. Leave at door if no answer.",
  },
  {
    id: "ORD-2024-002",
    customerName: "Michael Chen",
    email: "mike.chen@techcorp.com",
    phone: "+1 (555) 987-6543",
    address: "456 Oak Avenue, Suite 200, Business District, New York, NY 10002",
    items: [
      { id: "5", name: "Grilled Chicken Caesar Salad", quantity: 1, price: 14.99, category: "Salads" },
      { id: "6", name: "Chicken Tenders (8pc)", quantity: 1, price: 13.99, category: "Tenders" },
      { id: "7", name: "Honey Mustard Sauce", quantity: 2, price: 0.99, category: "Sauces" },
      { id: "8", name: "Iced Tea (Large)", quantity: 1, price: 2.99, category: "Beverages" },
    ],
    subtotal: 33.95,
    tax: 2.72,
    deliveryFee: 2.99,
    total: 39.66,
    status: "preparing",
    orderTime: new Date(Date.now() - 12 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() + 18 * 60 * 1000),
  },
  {
    id: "ORD-2024-003",
    customerName: "Emily Rodriguez",
    email: "emily.rodriguez@university.edu",
    phone: "+1 (555) 456-7890",
    address: "789 Pine Street, Dorm Building C, Room 305, University Campus, NY 10003",
    items: [
      { id: "9", name: "BBQ Chicken Pizza (Large)", quantity: 1, price: 22.99, category: "Pizza" },
      { id: "10", name: "Chicken Nuggets (20pc)", quantity: 1, price: 11.99, category: "Nuggets" },
      { id: "11", name: "Ranch Dressing", quantity: 3, price: 0.99, category: "Sauces" },
    ],
    subtotal: 37.95,
    tax: 3.04,
    deliveryFee: 1.99,
    total: 42.98,
    status: "out-for-delivery",
    orderTime: new Date(Date.now() - 25 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() + 8 * 60 * 1000),
    specialInstructions: "Student ID required for campus delivery. Call when arrived.",
  },
  {
    id: "ORD-2024-004",
    customerName: "David Wilson",
    email: "david.wilson@gmail.com",
    phone: "+1 (555) 321-0987",
    address: "321 Elm Drive, House #15, Suburban Heights, NY 10004",
    items: [
      { id: "12", name: "Chicken Burrito Bowl", quantity: 2, price: 16.99, category: "Bowls" },
      { id: "13", name: "Guacamole (Large)", quantity: 1, price: 4.99, category: "Sides" },
      { id: "14", name: "Churros (6pc)", quantity: 1, price: 7.99, category: "Desserts" },
    ],
    subtotal: 46.96,
    tax: 3.76,
    deliveryFee: 4.99,
    total: 55.71,
    status: "delivered",
    orderTime: new Date(Date.now() - 75 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() - 45 * 60 * 1000),
  },
  {
    id: "ORD-2024-005",
    customerName: "Jessica Thompson",
    email: "jess.thompson@design.co",
    phone: "+1 (555) 654-3210",
    address: "567 Maple Lane, Creative District, Loft 8A, NY 10005",
    items: [
      { id: "15", name: "Nashville Hot Chicken Sandwich", quantity: 1, price: 15.99, category: "Sandwiches" },
      { id: "16", name: "Sweet Potato Fries", quantity: 1, price: 7.99, category: "Sides" },
      { id: "17", name: "Milkshake - Vanilla", quantity: 1, price: 5.99, category: "Beverages" },
    ],
    subtotal: 29.97,
    tax: 2.4,
    deliveryFee: 3.49,
    total: 35.86,
    status: "preparing",
    orderTime: new Date(Date.now() - 8 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() + 22 * 60 * 1000),
    specialInstructions: "Extra napkins please. Allergic to peanuts.",
  },
  {
    id: "ORD-2024-006",
    customerName: "Robert Martinez",
    email: "rob.martinez@law.com",
    phone: "+1 (555) 789-0123",
    address: "890 Broadway, Floor 12, Financial District, NY 10006",
    items: [
      { id: "18", name: "Chicken Parmigiana", quantity: 1, price: 19.99, category: "Entrees" },
      { id: "19", name: "Garlic Bread", quantity: 1, price: 4.99, category: "Sides" },
      { id: "20", name: "Caesar Salad", quantity: 1, price: 8.99, category: "Salads" },
    ],
    subtotal: 33.97,
    tax: 2.72,
    deliveryFee: 2.99,
    total: 39.68,
    status: "pending",
    orderTime: new Date(Date.now() - 1 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() + 29 * 60 * 1000),
  },
  {
    id: "ORD-2024-007",
    customerName: "Amanda Foster",
    email: "amanda.foster@hospital.org",
    phone: "+1 (555) 234-5678",
    address: "234 Health Plaza, Medical Center, Staff Quarters B, NY 10007",
    items: [
      { id: "21", name: "Chicken Wrap - Mediterranean", quantity: 3, price: 11.99, category: "Wraps" },
      { id: "22", name: "Fruit Cup", quantity: 3, price: 3.99, category: "Sides" },
      { id: "23", name: "Bottled Water", quantity: 3, price: 1.99, category: "Beverages" },
    ],
    subtotal: 53.91,
    tax: 4.31,
    deliveryFee: 4.99,
    total: 63.21,
    status: "out-for-delivery",
    orderTime: new Date(Date.now() - 35 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() + 5 * 60 * 1000),
    specialInstructions: "Hospital delivery - ask for Amanda at reception desk.",
  },
  {
    id: "ORD-2024-008",
    customerName: "Kevin Park",
    email: "kevin.park@startup.io",
    phone: "+1 (555) 345-6789",
    address: "345 Innovation Way, Tech Hub, Floor 3, NY 10008",
    items: [
      { id: "24", name: "Korean BBQ Chicken Bowl", quantity: 1, price: 17.99, category: "Bowls" },
      { id: "25", name: "Kimchi Fried Rice", quantity: 1, price: 9.99, category: "Sides" },
      { id: "26", name: "Green Tea", quantity: 1, price: 2.99, category: "Beverages" },
    ],
    subtotal: 30.97,
    tax: 2.48,
    deliveryFee: 3.99,
    total: 37.44,
    status: "delivered",
    orderTime: new Date(Date.now() - 95 * 60 * 1000),
    estimatedDelivery: new Date(Date.now() - 65 * 60 * 1000),
  },
  {
    id: "ORD-2024-009",
    customerName: "Lisa Chang",
    email: "lisa.chang@marketing.com",
    phone: "+1 (555) 111-2222",
    address: "111 Creative Street, Art District, NY 10009",
    items: [
      { id: "27", name: "Honey Garlic Wings (8pc)", quantity: 1, price: 16.99, category: "Wings" },
      { id: "28", name: "Coleslaw", quantity: 1, price: 4.99, category: "Sides" },
    ],
    subtotal: 21.98,
    tax: 1.76,
    deliveryFee: 2.99,
    total: 26.73,
    status: "cancelled",
    orderTime: new Date(Date.now() - 45 * 60 * 1000),
    specialInstructions: "Customer cancelled - refund processed",
  },
]

const statusColors = {
  pending: "bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100",
  preparing: "bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100",
  "out-for-delivery": "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100",
  delivered: "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100",
  cancelled: "bg-red-50 text-red-700 border-red-200 hover:bg-red-100",
}

const statusIcons = {
  pending: Clock,
  preparing: Package,
  "out-for-delivery": Truck,
  delivered: CheckCircle,
  cancelled: X,
}

const statusLabels = {
  pending: "Pending",
  preparing: "Preparing",
  "out-for-delivery": "Out for Delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
}

export default function AdminDashboard() {
  const [orders, setOrders] = useState<Order[]>(sampleDatabase)
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [newOrderAlert, setNewOrderAlert] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [activeTab, setActiveTab] = useState<"all" | OrderStatus>("all")

  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000)
    return () => clearInterval(timer)
  }, [])

  // Simulate new order notifications every 30-60 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        setNewOrderAlert(true)
        // Simulate adding a new order
        const newOrder: Order = {
          id: `ORD-2024-${String(orders.length + 1).padStart(3, "0")}`,
          customerName: "New Customer",
          email: "new.customer@email.com",
          phone: "+1 (555) 000-0000",
          address: "New Address, City, State",
          items: [{ id: "new", name: "New Order Item", quantity: 1, price: 15.99, category: "New" }],
          subtotal: 15.99,
          tax: 1.28,
          deliveryFee: 2.99,
          total: 20.26,
          status: "pending",
          orderTime: new Date(),
          estimatedDelivery: new Date(Date.now() + 30 * 60 * 1000),
        }
        setOrders((prev) => [newOrder, ...prev])
        setTimeout(() => setNewOrderAlert(false), 5000)
      }
    }, 45000)

    return () => clearInterval(interval)
  }, [orders.length])

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders(
      orders.map((order) =>
        order.id === orderId
          ? {
              ...order,
              status: newStatus,
              estimatedDelivery:
                newStatus === "delivered"
                  ? new Date()
                  : new Date(Date.now() + (newStatus === "out-for-delivery" ? 10 : 20) * 60 * 1000),
            }
          : order,
      ),
    )
    if (selectedOrder?.id === orderId) {
      setSelectedOrder({ ...selectedOrder, status: newStatus })
    }
  }

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      setIsRefreshing(false)
      // Simulate some status updates
      setOrders((prev) =>
        prev.map((order) => {
          if (Math.random() > 0.8 && order.status !== "delivered" && order.status !== "cancelled") {
            const statuses: OrderStatus[] = ["pending", "preparing", "out-for-delivery", "delivered"]
            const currentIndex = statuses.indexOf(order.status)
            const nextStatus = statuses[Math.min(currentIndex + 1, statuses.length - 1)]
            return { ...order, status: nextStatus }
          }
          return order
        }),
      )
    }, 1500)
  }

  // Get orders based on active tab
  const getCurrentOrders = () => {
    let baseOrders = orders

    // Filter by tab
    if (activeTab !== "all") {
      baseOrders = orders.filter((order) => order.status === activeTab)
    }

    // Apply search filter
    return baseOrders.filter((order) => {
      const searchMatch =
        order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.phone.includes(searchTerm)
      return searchMatch
    })
  }

  const currentOrders = getCurrentOrders()

  const getStatusCounts = () => {
    return {
      all: orders.length,
      pending: orders.filter((o) => o.status === "pending").length,
      preparing: orders.filter((o) => o.status === "preparing").length,
      "out-for-delivery": orders.filter((o) => o.status === "out-for-delivery").length,
      delivered: orders.filter((o) => o.status === "delivered").length,
      cancelled: orders.filter((o) => o.status === "cancelled").length,
    }
  }

  const getTodayStats = () => {
    const today = new Date()
    const todayOrders = orders.filter((order) => order.orderTime.toDateString() === today.toDateString())
    const revenue = todayOrders.reduce((sum, order) => sum + order.total, 0)
    const avgOrderValue = todayOrders.length > 0 ? revenue / todayOrders.length : 0

    return {
      ordersToday: todayOrders.length,
      revenue: revenue,
      avgOrderValue: avgOrderValue,
    }
  }

  const statusCounts = getStatusCounts()
  const todayStats = getTodayStats()

  const getTimeAgo = (date: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))

    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`
    return `${Math.floor(diffInMinutes / 1440)}d ago`
  }

  const getEstimatedTime = (date: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((date.getTime() - now.getTime()) / (1000 * 60))

    if (diffInMinutes <= 0) return "Now"
    if (diffInMinutes < 60) return `${diffInMinutes} min`
    return `${Math.floor(diffInMinutes / 60)}h ${diffInMinutes % 60}m`
  }

  const renderOrderCard = (order: Order) => {
    const StatusIcon = statusIcons[order.status]
    return (
      <Card
        key={order.id}
        className={`transition-all duration-200 hover:shadow-lg border-l-4 ${
          selectedOrder?.id === order.id
            ? "ring-2 ring-red-500 border-l-red-500 shadow-lg"
            : order.status === "pending"
              ? "border-l-amber-400"
              : order.status === "preparing"
                ? "border-l-blue-400"
                : order.status === "out-for-delivery"
                  ? "border-l-purple-400"
                  : order.status === "delivered"
                    ? "border-l-emerald-400"
                    : "border-l-red-400"
        }`}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center space-x-3 cursor-pointer flex-1" onClick={() => setSelectedOrder(order)}>
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-gradient-to-br from-red-100 to-red-200 text-red-700 font-semibold">
                  {order.customerName
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold text-gray-900">{order.customerName}</h3>
                <p className="text-sm text-gray-500 font-mono">{order.id}</p>
              </div>
            </div>

            {/* Status Change Dropdown */}
            <div className="flex flex-col items-end space-y-2">
              <Select
                value={order.status}
                onValueChange={(newStatus: OrderStatus) => updateOrderStatus(order.id, newStatus)}
                disabled={order.status === "delivered" || order.status === "cancelled"}
              >
                <SelectTrigger className={`w-40 h-8 text-xs ${statusColors[order.status]} border`}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending" className="text-xs">
                    <div className="flex items-center">
                      <Clock className="w-3 h-3 mr-2" />
                      Pending
                    </div>
                  </SelectItem>
                  <SelectItem value="preparing" className="text-xs">
                    <div className="flex items-center">
                      <Package className="w-3 h-3 mr-2" />
                      Preparing
                    </div>
                  </SelectItem>
                  <SelectItem value="out-for-delivery" className="text-xs">
                    <div className="flex items-center">
                      <Truck className="w-3 h-3 mr-2" />
                      Out for Delivery
                    </div>
                  </SelectItem>
                  <SelectItem value="delivered" className="text-xs">
                    <div className="flex items-center">
                      <CheckCircle className="w-3 h-3 mr-2" />
                      Delivered
                    </div>
                  </SelectItem>
                  <SelectItem value="cancelled" className="text-xs">
                    <div className="flex items-center">
                      <X className="w-3 h-3 mr-2" />
                      Cancelled
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>

              {order.estimatedDelivery && order.status !== "delivered" && order.status !== "cancelled" && (
                <p className="text-xs text-gray-500">ETA: {getEstimatedTime(order.estimatedDelivery)}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-600">{order.items.length} item(s)</p>
              <p className="font-bold text-lg text-gray-900">${order.total.toFixed(2)}</p>
            </div>

            <div className="flex justify-between items-center text-xs text-gray-500">
              <span>{getTimeAgo(order.orderTime)}</span>
              <span className="flex items-center">
                <MapPin className="w-3 h-3 mr-1" />
                {order.address.split(",")[0]}
              </span>
            </div>

            {order.status === "preparing" && (
              <div className="mt-2">
                <div className="flex justify-between text-xs text-gray-600 mb-1">
                  <span>Preparation Progress</span>
                  <span>75%</span>
                </div>
                <Progress value={75} className="h-2" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Enhanced Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-red-700 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">DD</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Doro Dash Admin</h1>
                <p className="text-sm text-gray-500">Order Management Dashboard</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-medium text-gray-900">{currentTime.toLocaleTimeString()}</p>
                <p className="text-xs text-gray-500">{currentTime.toLocaleDateString()}</p>
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={isRefreshing}
                className="hover:bg-gray-50"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
                {isRefreshing ? "Refreshing..." : "Refresh"}
              </Button>

              <div className="relative">
                <Bell
                  className={`w-6 h-6 transition-colors ${newOrderAlert ? "text-red-600 animate-bounce" : "text-gray-600 hover:text-gray-800"}`}
                />
                {newOrderAlert && (
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-600 rounded-full animate-ping"></div>
                )}
              </div>

              <Button variant="ghost" size="sm" className="hover:bg-gray-100">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="px-4 sm:px-6 lg:px-8 py-6">
        {/* Enhanced Stats Section */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4 mb-8">
          {/* Order Status Cards */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-amber-600">{statusCounts.pending}</p>
                </div>
                <div className="p-2 bg-amber-100 rounded-lg">
                  <Clock className="w-6 h-6 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Preparing</p>
                  <p className="text-2xl font-bold text-blue-600">{statusCounts.preparing}</p>
                </div>
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Package className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Out for Delivery</p>
                  <p className="text-2xl font-bold text-purple-600">{statusCounts["out-for-delivery"]}</p>
                </div>
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Truck className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Delivered</p>
                  <p className="text-2xl font-bold text-emerald-600">{statusCounts.delivered}</p>
                </div>
                <div className="p-2 bg-emerald-100 rounded-lg">
                  <CheckCircle className="w-6 h-6 text-emerald-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Additional Stats */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Today's Orders</p>
                  <p className="text-2xl font-bold text-gray-900">{todayStats.ordersToday}</p>
                </div>
                <div className="p-2 bg-gray-100 rounded-lg">
                  <Calendar className="w-6 h-6 text-gray-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Revenue</p>
                  <p className="text-2xl font-bold text-green-600">${todayStats.revenue.toFixed(0)}</p>
                </div>
                <div className="p-2 bg-green-100 rounded-lg">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Order</p>
                  <p className="text-2xl font-bold text-indigo-600">${todayStats.avgOrderValue.toFixed(0)}</p>
                </div>
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-indigo-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Filters */}
        <Card className="mb-6 shadow-sm">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search by customer name, order ID, or phone number..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 border-gray-300 focus:border-red-500 focus:ring-red-500"
                  />
                </div>
              </div>
              <Button variant="outline" className="hover:bg-gray-50">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Orders List with Status Tabs */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">Orders</h2>
              <Badge variant="outline" className="text-sm">
                Live Updates
              </Badge>
            </div>

            {/* Status Tabs */}
            <Tabs
              value={activeTab}
              onValueChange={(value) => setActiveTab(value as "all" | OrderStatus)}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-6 h-auto p-1">
                <TabsTrigger value="all" className="flex flex-col items-center py-2 px-1 text-xs">
                  <span className="font-medium">All</span>
                  <Badge variant="secondary" className="mt-1 text-xs px-1.5 py-0.5">
                    {statusCounts.all}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="pending" className="flex flex-col items-center py-2 px-1 text-xs">
                  <div className="flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    <span className="font-medium">Pending</span>
                  </div>
                  <Badge variant="secondary" className="mt-1 text-xs px-1.5 py-0.5 bg-amber-100 text-amber-700">
                    {statusCounts.pending}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="preparing" className="flex flex-col items-center py-2 px-1 text-xs">
                  <div className="flex items-center">
                    <Package className="w-3 h-3 mr-1" />
                    <span className="font-medium">Preparing</span>
                  </div>
                  <Badge variant="secondary" className="mt-1 text-xs px-1.5 py-0.5 bg-blue-100 text-blue-700">
                    {statusCounts.preparing}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="out-for-delivery" className="flex flex-col items-center py-2 px-1 text-xs">
                  <div className="flex items-center">
                    <Truck className="w-3 h-3 mr-1" />
                    <span className="font-medium">Delivery</span>
                  </div>
                  <Badge variant="secondary" className="mt-1 text-xs px-1.5 py-0.5 bg-purple-100 text-purple-700">
                    {statusCounts["out-for-delivery"]}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="delivered" className="flex flex-col items-center py-2 px-1 text-xs">
                  <div className="flex items-center">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    <span className="font-medium">Delivered</span>
                  </div>
                  <Badge variant="secondary" className="mt-1 text-xs px-1.5 py-0.5 bg-emerald-100 text-emerald-700">
                    {statusCounts.delivered}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="cancelled" className="flex flex-col items-center py-2 px-1 text-xs">
                  <div className="flex items-center">
                    <X className="w-3 h-3 mr-1" />
                    <span className="font-medium">Cancelled</span>
                  </div>
                  <Badge variant="secondary" className="mt-1 text-xs px-1.5 py-0.5 bg-red-100 text-red-700">
                    {statusCounts.cancelled}
                  </Badge>
                </TabsTrigger>
              </TabsList>

              {/* Tab Content */}
              {(["all", "pending", "preparing", "out-for-delivery", "delivered", "cancelled"] as const).map(
                (status) => (
                  <TabsContent key={status} value={status} className="mt-4">
                    <div className="space-y-3 max-h-[800px] overflow-y-auto">
                      {currentOrders.map((order) => renderOrderCard(order))}

                      {currentOrders.length === 0 && (
                        <Card>
                          <CardContent className="p-8 text-center">
                            <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                            <p className="text-gray-500">
                              {activeTab === "all"
                                ? "No orders found matching your search criteria"
                                : `No ${statusLabels[activeTab as OrderStatus]?.toLowerCase()} orders found`}
                            </p>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  </TabsContent>
                ),
              )}
            </Tabs>
          </div>

          {/* Enhanced Order Details */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">Order Details</h2>

            {selectedOrder ? (
              <Card className="shadow-lg">
                <CardHeader className="bg-gradient-to-r from-red-50 to-red-100 border-b">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg font-bold">{selectedOrder.id}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">Ordered {getTimeAgo(selectedOrder.orderTime)}</p>
                    </div>
                    <Badge className={`${statusColors[selectedOrder.status]} border text-sm font-medium`}>
                      {selectedOrder.status.replace("-", " ").toUpperCase()}
                    </Badge>
                  </div>
                </CardHeader>

                <CardContent className="p-6 space-y-6">
                  <Tabs defaultValue="details" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="details">Details</TabsTrigger>
                      <TabsTrigger value="timeline">Timeline</TabsTrigger>
                    </TabsList>

                    <TabsContent value="details" className="space-y-6 mt-4">
                      {/* Customer Information */}
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                          <User className="w-4 h-4 mr-2 text-red-600" />
                          Customer Information
                        </h4>
                        <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                          <div className="grid grid-cols-1 gap-2 text-sm">
                            <div className="flex justify-between">
                              <span className="font-medium text-gray-600">Name:</span>
                              <span className="text-gray-900">{selectedOrder.customerName}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="font-medium text-gray-600">Email:</span>
                              <span className="text-gray-900">{selectedOrder.email}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="font-medium text-gray-600">Phone:</span>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-1 text-blue-600 hover:text-blue-800"
                              >
                                <Phone className="w-3 h-3 mr-1" />
                                {selectedOrder.phone}
                              </Button>
                            </div>
                            <div className="pt-2 border-t">
                              <span className="font-medium text-gray-600 flex items-start">
                                <MapPin className="w-4 h-4 mr-1 mt-0.5 text-red-600" />
                                <span className="text-gray-900">{selectedOrder.address}</span>
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Order Items */}
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Order Items</h4>
                        <div className="space-y-3">
                          {selectedOrder.items.map((item) => (
                            <div key={item.id} className="flex justify-between items-start p-3 bg-gray-50 rounded-lg">
                              <div className="flex-1">
                                <p className="font-medium text-gray-900">{item.name}</p>
                                <div className="flex items-center space-x-2 mt-1">
                                  <Badge variant="outline" className="text-xs">
                                    {item.category}
                                  </Badge>
                                  <span className="text-sm text-gray-500">Qty: {item.quantity}</span>
                                </div>
                                {item.specialInstructions && (
                                  <p className="text-xs text-amber-600 mt-1 italic">Note: {item.specialInstructions}</p>
                                )}
                              </div>
                              <div className="text-right">
                                <p className="font-semibold text-gray-900">
                                  ${(item.price * item.quantity).toFixed(2)}
                                </p>
                                <p className="text-xs text-gray-500">${item.price.toFixed(2)} each</p>
                              </div>
                            </div>
                          ))}

                          {/* Order Summary */}
                          <div className="border-t pt-3 space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-600">Subtotal:</span>
                              <span className="text-gray-900">${selectedOrder.subtotal.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-600">Tax:</span>
                              <span className="text-gray-900">${selectedOrder.tax.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span className="text-gray-600">Delivery Fee:</span>
                              <span className="text-gray-900">${selectedOrder.deliveryFee.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between font-bold text-lg border-t pt-2">
                              <span className="text-gray-900">Total:</span>
                              <span className="text-red-600">${selectedOrder.total.toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {selectedOrder.specialInstructions && (
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                            <MessageSquare className="w-4 h-4 mr-2 text-red-600" />
                            Special Instructions
                          </h4>
                          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                            <p className="text-sm text-amber-800">{selectedOrder.specialInstructions}</p>
                          </div>
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="timeline" className="mt-4">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-3 p-3 bg-emerald-50 rounded-lg">
                          <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                          <div>
                            <p className="text-sm font-medium text-emerald-800">Order Placed</p>
                            <p className="text-xs text-emerald-600">{selectedOrder.orderTime.toLocaleString()}</p>
                          </div>
                        </div>

                        {selectedOrder.status !== "pending" && selectedOrder.status !== "cancelled" && (
                          <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            <div>
                              <p className="text-sm font-medium text-blue-800">Preparation Started</p>
                              <p className="text-xs text-blue-600">
                                {new Date(selectedOrder.orderTime.getTime() + 5 * 60 * 1000).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        )}

                        {(selectedOrder.status === "out-for-delivery" || selectedOrder.status === "delivered") && (
                          <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                            <div>
                              <p className="text-sm font-medium text-purple-800">Out for Delivery</p>
                              <p className="text-xs text-purple-600">
                                {new Date(selectedOrder.orderTime.getTime() + 20 * 60 * 1000).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        )}

                        {selectedOrder.status === "delivered" && (
                          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <div>
                              <p className="text-sm font-medium text-green-800">Delivered</p>
                              <p className="text-xs text-green-600">
                                {selectedOrder.estimatedDelivery?.toLocaleString()}
                              </p>
                            </div>
                          </div>
                        )}

                        {selectedOrder.status === "cancelled" && (
                          <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
                            <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                            <div>
                              <p className="text-sm font-medium text-red-800">Order Cancelled</p>
                              <p className="text-xs text-red-600">
                                {new Date(selectedOrder.orderTime.getTime() + 10 * 60 * 1000).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </TabsContent>
                  </Tabs>

                  <Separator />

                  {/* Enhanced Status Update Buttons */}
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Update Order Status</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        variant={selectedOrder.status === "pending" ? "default" : "outline"}
                        size="sm"
                        onClick={() => updateOrderStatus(selectedOrder.id, "pending")}
                        className={`${
                          selectedOrder.status === "pending"
                            ? "bg-amber-600 hover:bg-amber-700 text-white"
                            : "hover:bg-amber-50 hover:text-amber-700 hover:border-amber-300"
                        } transition-all duration-200`}
                        disabled={selectedOrder.status === "delivered" || selectedOrder.status === "cancelled"}
                      >
                        <Clock className="w-4 h-4 mr-1" />
                        Pending
                      </Button>

                      <Button
                        variant={selectedOrder.status === "preparing" ? "default" : "outline"}
                        size="sm"
                        onClick={() => updateOrderStatus(selectedOrder.id, "preparing")}
                        className={`${
                          selectedOrder.status === "preparing"
                            ? "bg-blue-600 hover:bg-blue-700 text-white"
                            : "hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300"
                        } transition-all duration-200`}
                        disabled={selectedOrder.status === "delivered" || selectedOrder.status === "cancelled"}
                      >
                        <Package className="w-4 h-4 mr-1" />
                        Preparing
                      </Button>

                      <Button
                        variant={selectedOrder.status === "out-for-delivery" ? "default" : "outline"}
                        size="sm"
                        onClick={() => updateOrderStatus(selectedOrder.id, "out-for-delivery")}
                        className={`${
                          selectedOrder.status === "out-for-delivery"
                            ? "bg-purple-600 hover:bg-purple-700 text-white"
                            : "hover:bg-purple-50 hover:text-purple-700 hover:border-purple-300"
                        } transition-all duration-200`}
                        disabled={selectedOrder.status === "delivered" || selectedOrder.status === "cancelled"}
                      >
                        <Truck className="w-4 h-4 mr-1" />
                        Out for Delivery
                      </Button>

                      <Button
                        variant={selectedOrder.status === "delivered" ? "default" : "outline"}
                        size="sm"
                        onClick={() => updateOrderStatus(selectedOrder.id, "delivered")}
                        className={`${
                          selectedOrder.status === "delivered"
                            ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                            : "hover:bg-emerald-50 hover:text-emerald-700 hover:border-emerald-300"
                        } transition-all duration-200`}
                        disabled={selectedOrder.status === "cancelled"}
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Delivered
                      </Button>

                      <Button
                        variant={selectedOrder.status === "cancelled" ? "default" : "outline"}
                        size="sm"
                        onClick={() => updateOrderStatus(selectedOrder.id, "cancelled")}
                        className={`${
                          selectedOrder.status === "cancelled"
                            ? "bg-red-600 hover:bg-red-700 text-white"
                            : "hover:bg-red-50 hover:text-red-700 hover:border-red-300"
                        } transition-all duration-200 col-span-2`}
                        disabled={selectedOrder.status === "delivered"}
                      >
                        <X className="w-4 h-4 mr-1" />
                        Cancel Order
                      </Button>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex space-x-2 pt-4 border-t">
                    <Button variant="outline" size="sm" className="flex-1 hover:bg-gray-50">
                      <Eye className="w-4 h-4 mr-2" />
                      View Receipt
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 hover:bg-gray-50">
                      <Phone className="w-4 h-4 mr-2" />
                      Call Customer
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="shadow-sm">
                <CardContent className="p-8 text-center">
                  <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Select an Order</h3>
                  <p className="text-gray-500">
                    Click on any order from the list to view detailed information and manage its status.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Enhanced New Order Alert */}
      {newOrderAlert && (
        <div className="fixed top-4 right-4 bg-gradient-to-r from-red-600 to-red-700 text-white p-4 rounded-lg shadow-xl animate-slide-in-right z-50 border border-red-500">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-white/20 rounded-full">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold">New Order Received!</p>
              <p className="text-sm text-red-100">Check the orders list for details</p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
